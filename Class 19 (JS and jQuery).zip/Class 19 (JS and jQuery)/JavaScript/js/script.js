// NESTING

		// Logical Operator &&, ||, !
		// != (not equal)

		// var my_GPA =  4.80; 
		// var my_SisterGPA =  5; 
		// var my_FatherAge = 60;
		// var my_MotherAge = 48;


		// if (my_GPA != my_SisterGPA) {
		// 	document.write("I am the bigger one");
		// }
		// else{
		// 	document.write("BD");
		// }



				/*imy_MotherAge >= 48 && my_FatherAge >= 60 && my_Age >= 25) {

					document.write("Our Code Is Correct");

				}else {

					document.write("Our Code Is NOT Correct");

				}*/


			// reminder Oboshistangsho 
			// Even and Odd
			// Jor and  Bejore

			// % Modulus operator. Returns remainder of two operands.

			// var n = 17; 
			// var result ;

			// var reminder = n % 2; // 0, 1


			// if (reminder == 0 ) {

			// 	result = "This number " + n + " is an EVEN number";
			// }else {
			// 	result = "This number "+ n +" is an ODD number";

			// }

			// document.write(result);



			// baby 0-1
			// toddler 1-3
			// kid 4-12
			// teenager 13-18
			// adult 18 =>


			var stages = {

							'1' : 'BABY',
							'3' : 'TODDLER',
							'7' : 'KID',
							'15' : 'TEENAGER',
							'19' : 'ADULT',
			}


			var sakibs_Age = 1; 
			var rofiqs_Age = 3;
			var nafis_Age = 7;
			var mashrafis_Age = 15;
			var ashrafuls_Age = 19;

			if (sakibs_Age <= 1) {
				document.write("Sakib is a "+ stages["1"]);
				document.write("<br/>");
			}else {
				document.write("He is not Born Yet");
			}


			if (rofiqs_Age <= 3) {
				document.write("Rofiq is a "+ stages["3"]);
				document.write("<br/>");
			}else {
				document.write("He is not Born Yet");
			}
			

			if (nafis_Age <= 7) {
				document.write("Nafis is a "+ stages["7"]);
				document.write("<br/>");
			}else {
				document.write("He is not Born Yet");
			}


			if (mashrafis_Age <= 15) {
				document.write("Mashrafi is a "+ stages["15"]);
				document.write("<br/>");
			}else {
				document.write("He is not Born Yet");
			}

			if (ashrafuls_Age <= 19) {
				document.write("Ashraful is an "+ stages["19"]);
				document.write("<br/>");
			}else {
				document.write("He is not Born Yet");
			}










				