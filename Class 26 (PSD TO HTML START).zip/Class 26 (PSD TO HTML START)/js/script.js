$(document).ready(function(){
	$('.video-play-btn').magnificPopup({
		type: 'video',
	});

	$('.mobile-icon').click(function(){
		$('.mobile-menu ul').slideToggle(1000);
	});
});