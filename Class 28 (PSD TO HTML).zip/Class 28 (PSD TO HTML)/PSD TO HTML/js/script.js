$(document).ready(function(){
	$('.video-play-btn').magnificPopup({
		type: 'video',
	});

	$('.mobile-icon').click(function(){
		$('.mobile-menu ul').slideToggle(1000);
	});

	$('.parallax-bg').parallaxie({
		speed: 0.9,
	});
	$('.head').parallaxie({
		speed: 0.9,
	});
});