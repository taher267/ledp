$(document).ready(function(){
	$('.video-play-btn').magnificPopup({
		type: 'video',
	});

	$('.mobile-icon').click(function(){
		$('.mobile-menu ul').slideToggle(1000);
	});

	$('.parallax-bg').parallaxie({
		speed: 0.9,
	});
	$('.head').parallaxie({
		speed: 0.9,
	});

	$('.owl-carousel').owlCarousel({
		loop:true,
		margin:10,
		nav:true,
		dots: false,
		responsive:{
			0:{
				items:3
			},
			600:{
				items:4
			},
			1000:{
				items:5
			}
		},
		autoplay: true,
		autoplayHoverPause: true,
		autoplaySpeed: 1000,
		navText: ['<i class="fa fa-long-arrow-left" aria-hidden="true"></i>', '<i class="fa fa-long-arrow-right" aria-hidden="true"></i>'],
	});
});