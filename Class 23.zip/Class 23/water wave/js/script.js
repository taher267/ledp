$('.head').ripples({
  dropRadius: 10,
  perturbance: 0.2
});