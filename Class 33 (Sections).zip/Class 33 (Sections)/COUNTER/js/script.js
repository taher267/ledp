jQuery(document).ready(function(){
    $('.counter').counterUp({
        delay: 50,
        time: 3000,
    });
});